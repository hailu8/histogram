# spr2021-a1: A1: Integrating PostgreSQL into a Visualization System

starter code for A1 for CMSC828D Spring 2021 (run using Python 3.5).

You will need the following python packages to run this code: `flask`, `psycopg2`.
```
pip install flask psycopg2
```

To run the server:
```
python server.py
```

The A1 webpage should be visible at the URL: localhost:8000/

Overview of the interface behavior:
* The starter code should produce a histogram visualization (a bar chart with numeric x-axis).
* The attribute being visualized can be controlled by clicking on a given button representing the attribute name (example: `Release\_Date`).
* The histogram can be filtered along the x-axis using a given range slider, to control what range of data values are counted
* The number of bins rendered in the histogram can be controlled using a given total bins slider.

A1 Goals:
* The goal of A1 is to translate the histogram binning and aggregation from the browser to the server.
* Students need to install PostgreSQL and get it running on their computer.
* The majority of the computation in `index.html` needs to happen in the DBMS PostgreSQL
  * see the `index.html` file and `server.py` file for more instructions.

Notes:
* Students may have to make some modest edits to the button, slider, and histogram visualization code to accept pre-computed data from the server.
* Assignments that do what is asked will get an A- (but given this is more of a training assignment, and a brand new assignment, we may be more lenient on the grading).
* Given that this assignment is largely a training exercise, it's okay to have code that is a bit messy. However, code quality will be considered when determining if a submission has gone "above and beyond" for grading purposes (i.e., to go from A- to A level).

Grading points (what we will be prioritizing in our grading):
* Can we run the code on our computers with no additional work (except setting up the given username and database for postgresql)?
* Was all computation translated to `server.py`?
* Was all aggregation translated to PostgreSQL queries? (it is ok to calculate bin ranges outside of PostgreSQL, if necessary)
* Was `index.html` updated appropriately to take pre-computed results from the server, instead of the raw data?
  * i.e., was the hardcoded fetch request for `movies.csv` replaced with new fetch calls for query results?
* How neat/organized is the submitted code?

Extras (going into A+ territory, only consider doing these if the points above have been addressed):
* Was there any additional improvement made to the interface? (examples: axis titles, filter slider not reset when bin slider is updated, proper datetime parsing/handling, etc.)

Submission instructions:
* make sure your submission is SELF CONTAINED in a single folder
  * to test, make a copy of your submission in a completely different location on your computer
  * try running the copy (if it breaks, you know you were relying on hardcoded files/file paths/parameters somewhere in your submission)
* make a separate file called `cmsc828d\_submission.md`
  * include your name and email in `cmsc828d\_submission.md`
  * Include any notes/rationale/general comments regarding your A1 submission in `cmsc828d\_submission.md`
* make a zipped version of your submission folder
* submit the zip file to ELMS on the A1 page
