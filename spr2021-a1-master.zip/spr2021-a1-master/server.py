import csv
try:
    import simplejson as json
except ImportError:
    import json
from flask import Flask,request,Response,render_template
import psycopg2 # use this package to work with postgresql

from flask_cors import CORS, cross_origin
app = Flask(__name__)
CORS(app)

def connect():
  try:
    conn = psycopg2.connect("dbname='a1database' user='cmsc828d' host='localhost' password='1234'")
    cur = conn.cursor()
    print ("connected! yay!")
    cur.execute('SELECT version()')

    # version = cur.fetchone()[0]
    # print(version)
  except: 
    print ("I am unable to connect to the database")
  return cur


def query_db(sql):
  cur = connect()
  cur.execute(sql)
  res = cur.fetchall()
  resp = Response(response=json.dumps(res),status=200, mimetype='application/json')
  h = resp.headers
  h['Access-Control-Allow-Origin'] = "*"
  return resp
  

def execute_sql(sql):

  cur = connect()
  cur.execute(sql)
  res = cur.fetchall()
  return res


@app.route('/')
@cross_origin(supports_credentials=True)
def renderPage():
  return render_template("index.html")

@app.route('/filter-data')
@cross_origin(supports_credentials=True)
def filterdata():
  column_name = request.args.get('column_name')
  sql ="select count(" + column_name + ") as count_of_ratings from movies group by (" + column_name + ") order by (" + column_name + ") asc"
  return query_db(sql)

@app.route('/min_maxval')
@cross_origin(supports_credentials=True)
def min_maxval():
  column_name = request.args.get('column_name')
  sql = "select min(" + column_name + ") min_col, max(" + column_name +") max_col  from movies"
  # sql = "select min(IMDB_Rating) as min_col, max(IMDB_Rating) max_col  from movies"
  return query_db(sql)
#  [i[0] for i in a]

@app.route('/compute_bin_ranges') 
@cross_origin(supports_credentials=True)
# def compute_bin_ranges(total_bins, column_name): this one causes error
# error compute_bin_ranges() missing 2 required positional arguments: 'total_bins' and 'column_name'
def compute_bin_ranges(total_bins, column_name): # add column_name later on
  column_name = request.args.get('column_name')
  total_bins = request.args.get('total_bins')
  sql = "select min(" + column_name + ") min_col, max(" +column_name+") max_col  from movies"
  # sql = """select min(IMDB_Rating) as min_col, max(IMDB_Rating) max_col  from movies"""
  result = execute_sql(sql)
  mx = result[0][1] 
  mn = result[0][0]
  step = (mx-mn)/total_bins
  bin_ranges = [] 
  prev = mn
  for i in range(0, total_bins): 
    bin_ranges.append({"range_min":prev,"range_max":prev+step})
    prev += step
  bin_ranges[len(bin_ranges)-1]['range_max'] = mx  # edge case: slight rounding issues
  resp = Response(response=json.dumps(bin_ranges),status=200, mimetype='application/json')
  h = resp.headers
  h['Access-Control-Allow-Origin'] = "*"
  return resp
 #output looks like -> [{"range_min": 0.3, "range_max": 1.01}, {"range_min": 1.01, "range_max": 1.7200000000000002}, 
 # {"range_min": 1.7200000000000002, "range_max": 2.43}, {"range_min": 2.43, "range_max": 3.14}, {"range_min"


# @app.route('/compute_bin/<int:total_bin>/<column_name>)
@app.route('/compute_bin')
@cross_origin(supports_credentials=True)
def computeBins(total_bin, column_name):
    bin_ranges = compute_bin_ranges(total_bin,column_name)
    res =[0 for num in range(0, len(bin_ranges))]
    sql = "select " + column_name + " from movies"
    result= execute_sql(sql)
    data = result[0] #first column data is selected
    for d in data:
      if(d == bin_ranges[len(bin_ranges)-1].range_max):
        res[len(bin_ranges)-1] += 1 #edge case, equal to mx
        return
      for j in range(0,len(bin_ranges)):
        if(d < bin_ranges[j].range_max):
          res[j] +=1
          break
    # return res #returns the compute_bin result
    resp = Response(response=json.dumps(res),status=200, mimetype='application/json')
    h = resp.headers
    h['Access-Control-Allow-Origin'] = "*"
    return resp

@app.route('/get-alldata')
@cross_origin(supports_credentials=True)
def getAData():
  sql = """select * from movies """
  return query_db(sql)
#   #this gives result [[row by row]] which is a tuple of tuple



# @app.route('/get-data') 
# def getData():
#   # 'pass the argument name in here'
#   # colmn_name = request.args.get('colmn_name') 
#   filename = request.args.get('filename') 
#   data = []
#   try:
#     with open(filename, 'r') as f:
#       reader = csv.DictReader(f)
#       for row in reader:
#         data.append(row)
#     #data = json.load(open(filename))
#     resp = Response(response=json.dumps(data),status=200, mimetype='application/json')
#     h = resp.headers
#     h['Access-Control-Allow-Origin'] = "*"
#     return resp
#   except Exception as err:
#     #print(err)
#     #return str(err)
#     raise err

# @app.route('/get-rating-count')
# def getRatingCount():
#   # sql = "select min(IMDB_Rating) as min_col, max(IMDB_Rating) max_col  from movies"
#   # sql = """select IMDB_Rating, count(IMDB_Rating) as count_of_ratings 
#   #             from movies 
#   #             group by IMDB_Rating 
#   #             order by IMDB_Rating asc"""
#   sql = """select * from movies """
#   #this gives result [[row by row]] which is a tuple of tuple

#   return query_db(sql)
 
'''
FOR A1 THE SERVER MUST:
1) connect to a local version of psycopg2 with user 'cmsc828d' and database 'a1database'
2) only fetch data from postgresql (you cannot just work with the raw data file using this server.py file)
3) only return aggregated data (you cannot just return the full dataset from postgresql to index.html)
4) The data must be filtered and aggregated using postgresql. This means you have to compute the bins and bin counts using postgresql.
Note: it is fine if you decide to calculate the bins outside of postgresql. But the extrema of the dataset (minimum, maximum) and actual bin counts must be calculated using postgresql.
'''

if __name__ == "__main__":
  app.run(debug=True,port=8000)
